@echo off
cd /d "%~dp0"
start "" "SpamPhim.exe" /uninstall
