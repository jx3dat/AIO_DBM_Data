@echo off
start "" "%~dp0AIO_Voice.exe"
exit
