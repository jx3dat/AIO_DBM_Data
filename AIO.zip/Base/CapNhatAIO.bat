@echo off
rem [c506] Mo trinh cap nhat AIO (CapNhatAIO.ps1) bang PowerShell AN, roi dong cua so nay ngay.
rem Tien do / ket qua hien trong bang "Cap nhat AIO" trong game. Chay tay de xem chi tiet: CapNhatAIO.bat show
setlocal
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=powershell"
if /i "%~1"=="show" (
  "%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0CapNhatAIO.ps1"
  echo Ket qua: interface\@DATA\AIO_Update\done.jx3dat
  pause
  exit /b
)
start "" "%PS%" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0CapNhatAIO.ps1"
exit /b
