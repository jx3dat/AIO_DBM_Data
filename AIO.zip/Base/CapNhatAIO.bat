@echo off
rem [c500] Cap nhat AIO: tai release.txt -> lay link zip (dong "zip = ...") va so ban (dong "latest = ...")
rem -> tai zip, giai nen, chep de vao thu muc interface (khong dong vao interface\@DATA)
rem -> ghi interface\@DATA\AIO_Update\done.jx3dat de AIO trong game biet da cap nhat xong.
rem Can Windows 10/11 (co san curl.exe va tar.exe). File nay phai nam trong interface\Base.
setlocal EnableExtensions
set "REL_URL=https://raw.githubusercontent.com/jx3dat/AIO_DBM_Data/main/release.txt"
title Cap nhat AIO
cd /d "%~dp0.."
if not exist "Base\Base80.lua" (
  echo Khong tim thay interface\Base\Base80.lua.
  echo Hay chay file nay tu thu muc interface\Base cua game.
  pause
  exit /b 1
)
set "IFACE=%CD%"
set "MARK=%IFACE%\@DATA\AIO_Update"
if not exist "%MARK%" mkdir "%MARK%"
set "WORK=%TEMP%\AIO_Update_%RANDOM%"
mkdir "%WORK%"

echo [1/4] Doc thong tin ban moi...
curl -fsSL -o "%WORK%\release.txt" "%REL_URL%?t=%RANDOM%"
if errorlevel 1 (set "ERR=release" & goto fail)
set "ZIP="
set "LATEST="
for /f "usebackq tokens=1,* delims==" %%a in ("%WORK%\release.txt") do call :kv "%%a" "%%b"
if not defined ZIP (set "ERR=no_zip" & goto fail)
if not defined LATEST set "LATEST=?"
echo     Ban moi: %LATEST%

echo [2/4] Tai goi AIO...
curl -fL -o "%WORK%\AIO.zip" "%ZIP%"
if errorlevel 1 (set "ERR=download" & goto fail)

echo [3/4] Giai nen...
mkdir "%WORK%\x"
tar -xf "%WORK%\AIO.zip" -C "%WORK%\x"
if errorlevel 1 (set "ERR=unzip" & goto fail)
rem tim thu muc goc trong zip: co Base\Base80.lua, hoac co interface\Base\Base80.lua, hoac 1 cap thu muc con
set "SRC="
if exist "%WORK%\x\Base\Base80.lua" set "SRC=%WORK%\x"
if not defined SRC if exist "%WORK%\x\interface\Base\Base80.lua" set "SRC=%WORK%\x\interface"
if not defined SRC for /d %%d in ("%WORK%\x\*") do (
  if exist "%%d\Base\Base80.lua" set "SRC=%%d"
  if exist "%%d\interface\Base\Base80.lua" set "SRC=%%d\interface"
)
if not defined SRC (set "ERR=zip_layout" & goto fail)

echo [4/4] Chep de vao %IFACE% ...
robocopy "%SRC%" "%IFACE%" /E /XD "@DATA" /R:2 /W:1 /NFL /NDL /NJH /NJS /NP
if errorlevel 8 (set "ERR=copy" & goto fail)

> "%MARK%\done.jx3dat" echo data = { ok = 1, ver = "%LATEST%", }
rd /s /q "%WORK%" 2>nul
echo.
echo Da cap nhat AIO ban %LATEST%. Quay lai game de tai lai giao dien / dang nhap lai.
timeout /t 8
exit /b 0

:fail
> "%MARK%\done.jx3dat" echo data = { ok = 0, err = "%ERR%", }
rd /s /q "%WORK%" 2>nul
echo.
echo CAP NHAT THAT BAI (%ERR%). Kiem tra mang hoac cap nhat bang tay.
pause
exit /b 1

:kv
set "K=%~1"
set "V=%~2"
for /f "tokens=* delims= " %%k in ("%K%") do set "K=%%k"
:trimk
if "%K:~-1%"==" " (set "K=%K:~0,-1%" & goto trimk)
for /f "tokens=* delims= " %%v in ("%V%") do set "V=%%v"
if not defined V exit /b 0
:trimv
if "%V:~-1%"==" " (set "V=%V:~0,-1%" & goto trimv)
if /i "%K%"=="zip" set "ZIP=%V%"
if /i "%K%"=="latest" set "LATEST=%V%"
exit /b 0
