# [c506] Trinh cap nhat AIO (chay an, do CapNhatAIO.bat goi). Tien do / ket qua ghi vao
# interface\@DATA\AIO_Update\done.jx3dat ("data = { ... }") de bang Cap nhat trong game doc moi 0.5 giay.
# Chi dung san cua Windows 10 (PowerShell 5 + .NET 4.5): khong can curl / tar / robocopy.
$ErrorActionPreference = 'Stop'
$RelUrl = 'https://raw.githubusercontent.com/jx3dat/AIO_DBM_Data/main/release.txt'

$BaseDir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$Iface    = Split-Path -Parent $BaseDir
$MarkDir  = Join-Path $Iface '@DATA\AIO_Update'
$MarkFile = Join-Path $MarkDir 'done.jx3dat'
$Work     = Join-Path $env:TEMP ('AIO_Update_' + [Guid]::NewGuid().ToString('N').Substring(0, 8))
$script:Latest = '?'

function Clean([string]$s) {
	if ($null -eq $s) { return '' }
	$s = $s -replace '[^\x20-\x7E]', '' -replace '["\\]', '/'
	if ($s.Length -gt 160) { $s = $s.Substring(0, 160) }
	return $s
}
function Mark([string]$body) {
	try {
		$tmp = $MarkFile + '.tmp'
		[IO.File]::WriteAllText($tmp, 'data = { ' + $body + ' }', [Text.Encoding]::ASCII)
		if (Test-Path -LiteralPath $MarkFile) { Remove-Item -LiteralPath $MarkFile -Force }
		Move-Item -LiteralPath $tmp -Destination $MarkFile -Force
	} catch {}
}
function Step([int]$n, [int]$pct, [string]$info) {
	Mark ('st = "run", step = ' + $n + ', pct = ' + $pct + ', ver = "' + (Clean $script:Latest) + '", info = "' + (Clean $info) + '",')
}
function Fail([string]$code, [string]$msg) {
	Mark ('st = "end", ok = 0, err = "' + (Clean $code) + '", msg = "' + (Clean $msg) + '", ver = "' + (Clean $script:Latest) + '",')
	try { if (Test-Path -LiteralPath $Work) { Remove-Item -LiteralPath $Work -Recurse -Force } } catch {}
	exit 1
}

if (-not (Test-Path -LiteralPath (Join-Path $BaseDir 'Base80.lua'))) { exit 2 } # khong o interface\Base
New-Item -ItemType Directory -Force -Path $MarkDir | Out-Null
# [c507] don rac cua lan chay truoc bi ngat giua chung (tat may, bi kill...)
try { Get-ChildItem -LiteralPath $env:TEMP -Directory -Filter 'AIO_Update_*' -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue } catch {}
New-Item -ItemType Directory -Force -Path $Work | Out-Null
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor 3072 } catch {}

# [1/4] release.txt
Step 1 0 ''
$zip = $null
try {
	$wc = New-Object Net.WebClient
	$wc.Encoding = [Text.Encoding]::UTF8
	$wc.Headers.Add('User-Agent', 'AIO-Update')
	$txt = $wc.DownloadString($RelUrl + '?t=' + [Guid]::NewGuid().ToString('N'))
} catch { Fail 'release' $_.Exception.Message }
foreach ($line in ($txt -split "`r?`n")) {
	if ($line -match '^\s*([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$') {
		$k = $matches[1].ToLower(); $v = $matches[2].Trim([char[]]@([char]34, [char]39, [char]32))
		if ($k -eq 'zip') { $zip = $v }
		elseif ($k -eq 'latest') { $script:Latest = $v }
	}
}
if (-not $zip) { Fail 'no_zip' '' }
$zip = $zip -replace '://github\.com/([^/]+)/([^/]+)/(blob|raw)/', '://raw.githubusercontent.com/$1/$2/'
Step 1 100 ''

# [2/4] tai zip (co %)
$zipPath = Join-Path $Work 'AIO.zip'
try {
	$req = [Net.HttpWebRequest]::Create($zip)
	$req.UserAgent = 'AIO-Update'
	$req.Timeout = 30000
	$resp = $req.GetResponse()
	$len = $resp.ContentLength
	$in = $resp.GetResponseStream()
	$out = [IO.File]::Create($zipPath)
	$buf = New-Object byte[] 65536
	$done = 0
	$last = [DateTime]::Now
	while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) {
		$out.Write($buf, 0, $n)
		$done += $n
		if (([DateTime]::Now - $last).TotalMilliseconds -ge 400) {
			$last = [DateTime]::Now
			$p = 0; if ($len -gt 0) { $p = [int](100 * $done / $len) }
			Step 2 $p ([string][int]($done / 1024) + ' KB')
		}
	}
	$out.Close(); $in.Close(); $resp.Close()
} catch { Fail 'download' $_.Exception.Message }
$fs = [IO.File]::OpenRead($zipPath); $sig = New-Object byte[] 2; [void]$fs.Read($sig, 0, 2); $fs.Close()
if ($sig[0] -ne 0x50 -or $sig[1] -ne 0x4B) { Fail 'notzip' '' }
Step 2 100 ([string][int]($done / 1024) + ' KB')

# [3/4] giai nen (co %)
$x = Join-Path $Work 'x'
try {
	Add-Type -AssemblyName System.IO.Compression.FileSystem
	$za = [IO.Compression.ZipFile]::OpenRead($zipPath)
	$root = [IO.Path]::GetFullPath($x + '\')
	$total = $za.Entries.Count; $i = 0; $last = [DateTime]::Now
	foreach ($e in $za.Entries) {
		$i++
		$dest = [IO.Path]::GetFullPath((Join-Path $x $e.FullName))
		if (-not $dest.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) { continue } # chan duong dan ra ngoai
		if ($e.Name -eq '') { New-Item -ItemType Directory -Force -Path $dest | Out-Null; continue }
		New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dest) | Out-Null
		[IO.Compression.ZipFileExtensions]::ExtractToFile($e, $dest, $true)
		if (([DateTime]::Now - $last).TotalMilliseconds -ge 400) { $last = [DateTime]::Now; Step 3 ([int](100 * $i / $total)) '' }
	}
	$za.Dispose()
} catch { Fail 'unzip' $_.Exception.Message }
Step 3 100 ''

# thu muc goc trong zip: co Base\Base80.lua (hoac interface\Base\..., hoac 1 cap thu muc con)
$src = $null
foreach ($c in @($x, (Join-Path $x 'interface'))) { if (-not $src -and (Test-Path -LiteralPath (Join-Path $c 'Base\Base80.lua'))) { $src = $c } }
if (-not $src) {
	foreach ($d in (Get-ChildItem -LiteralPath $x -Directory)) {
		foreach ($c in @($d.FullName, (Join-Path $d.FullName 'interface'))) { if (-not $src -and (Test-Path -LiteralPath (Join-Path $c 'Base\Base80.lua'))) { $src = $c } }
	}
}
if (-not $src) { Fail 'zip_layout' '' }

# [4/4] chep de vao interface (bo qua @DATA)
$srcRoot = [IO.Path]::GetFullPath($src).TrimEnd('\') + '\'
$files = @(Get-ChildItem -LiteralPath $src -Recurse -File | Where-Object { $_.FullName.Substring($srcRoot.Length) -notmatch '^@DATA(\\|$)' })
$total = [Math]::Max(1, $files.Count); $i = 0; $bad = 0; $firstBad = ''; $last = [DateTime]::Now
foreach ($f in $files) {
	$i++
	$rel = $f.FullName.Substring($srcRoot.Length)
	$dest = Join-Path $Iface $rel
	try {
		New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dest) | Out-Null
		if (Test-Path -LiteralPath $dest) { (Get-Item -LiteralPath $dest -Force).Attributes = 'Normal' }
		Copy-Item -LiteralPath $f.FullName -Destination $dest -Force
	} catch { $bad++; if (-not $firstBad) { $firstBad = $rel + ': ' + $_.Exception.Message } }
	if (([DateTime]::Now - $last).TotalMilliseconds -ge 400) { $last = [DateTime]::Now; Step 4 ([int](100 * $i / $total)) ([string]$i + '/' + $files.Count) }
}
if ($bad -gt 0) { Fail 'copy' ([string]$bad + ' file. ' + $firstBad) }

try { Remove-Item -LiteralPath $Work -Recurse -Force } catch {}
Mark ('st = "end", ok = 1, ver = "' + (Clean $script:Latest) + '", n = ' + $files.Count + ',')
exit 0
